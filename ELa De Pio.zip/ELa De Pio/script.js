// Future features can go here
console.log("Welcome to Artivine!");
